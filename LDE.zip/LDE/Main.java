package LDE;

import java.util.Scanner;
import java.util.Random;

public class Main {

    public static void main(String[] args) {

        //Definindo atributos
        Scanner input = new Scanner(System.in);
        Random random = new Random();
        ListaDuplamenteEncadeada lde = new ListaDuplamenteEncadeada();


        lde.inserirNoInicio(10);
        System.out.println(lde.size());
        System.out.println(lde.encontrarMaximo());
        lde.inserirNoInicio(45);
        lde.inserirNoFim(2);
        lde.inserirNoInicio(86);
        lde.inserirNoFim(32);
        lde.inserirNoInicio(93);
        lde.inserirNoFim(77);
        lde.inserirNoInicio(14);
        System.out.println(lde.size());
        System.out.println(lde.encontrarMaximo());
        System.out.println(lde.encontrarMinimo());
    }
}
