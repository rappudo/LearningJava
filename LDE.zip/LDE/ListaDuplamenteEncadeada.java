package LDE;

public class ListaDuplamenteEncadeada {

    //Atributos
    private No inicio;
    private int tamanho;

    //Construtor
    public ListaDuplamenteEncadeada() {
        this.inicio = null;
        this.tamanho = 0;
    }

    //Métodos
    public boolean isEmpty() {
        return (inicio == null);
    }

    public void inserirNoInicio(int dado) {
        No novoNo = new No(dado);
        if (inicio == null) {
            inicio = novoNo;
            tamanho++;
        } else {
            novoNo.setProximoNo(inicio);
            inicio.setAnteriorNo(novoNo);
            inicio = novoNo;
            tamanho++;
        }
    }

    public void inserirNoFim(int dado) {
        No novoNo = new No(dado);
        if (inicio == null) {
            inicio = novoNo;
            tamanho++;
        } else {
            No temp = inicio;
            while (temp.getProximoNo() != null) {
                temp = temp.getProximoNo();
            }
            temp.setProximoNo(novoNo);
            novoNo.setAnteriorNo(temp);
            tamanho++;
        }
    }

    public String removerNo(int valor) {
        //Lista Vazia
        if (inicio == null)
            return "Valor não encontrado!";
        No temp = inicio;
        //Valor está no início
        if (temp.getDado() == valor){
            inicio = temp.getProximoNo();
            //Caso a lista tenha mais de um valor
            if (inicio != null)
                inicio.setAnteriorNo(null);
            tamanho--;
            return "Valor removido!";
        }
        //Percorrer a lista
        while (temp != null && temp.getDado() != valor){
            temp = temp.getProximoNo();
        }
        //Caso o valor exista na lista
        if (temp != null){
            //Caso tenha valores depois
            if (temp.getProximoNo() != null){
                temp.getProximoNo().setAnteriorNo(temp.getAnteriorNo());
            }
            //Caso tenha valores antes
            if (temp.getAnteriorNo() != null){
                temp.getAnteriorNo().setProximoNo(temp.getProximoNo());
            }
            tamanho--;
            return "Valor removido!";
        }
        return "Erro!";
    }

    public int size(){
        return tamanho;
    }

    public int encontrarMaximo(){
        No temp = inicio;
        int valor = temp.getDado();
        while(temp != null){
            if (valor < temp.getDado())
                valor = temp.getDado();
            temp = temp.getProximoNo();
        }
        return valor;
    }

    public int encontrarMinimo(){
        No temp = inicio;
        int valor = temp.getDado();
        while (temp != null){
            if (valor > temp.getDado())
                valor = temp.getDado();
            temp = temp.getProximoNo();
        }
        return valor;
    }
}

