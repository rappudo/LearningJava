package LDE;

public class No {

    //Atributos
    private int dado; //Informação
    private No proximoNo, anteriorNo; //Ponteiros

    //Construtor
    public No(int dado){
        this.dado = dado;
        this.proximoNo = proximoNo;
        this.anteriorNo = anteriorNo;

    }

    //Gets e sets
    public int getDado() {
        return dado;
    }

    public void setDado(int dado) {
        this.dado = dado;
    }

    public No getProximoNo() {
        return proximoNo;
    }

    public void setProximoNo(No proximoNo) {
        this.proximoNo = proximoNo;
    }

    public No getAnteriorNo() {
        return anteriorNo;
    }

    public void setAnteriorNo(No anteriorNo) {
        this.anteriorNo = anteriorNo;
    }

}
