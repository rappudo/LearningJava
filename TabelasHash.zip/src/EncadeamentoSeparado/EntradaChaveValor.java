package EncadeamentoSeparado;

public class EntradaChaveValor {

    private int chave;
    private String Valor;

    public EntradaChaveValor(int chave, String Valor) {
        this.chave = chave;
        this.Valor = Valor;
    }

    public int getChave() {
        return chave;
    }

    public String getValor() {
        return Valor;
    }

    public void setValor(String Valor) {
        this.Valor = Valor;
    }

    public String toString() {
        return "{" + chave + " = " + Valor + "}";
    }
}
