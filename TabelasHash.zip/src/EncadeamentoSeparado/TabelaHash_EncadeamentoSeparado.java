package EncadeamentoSeparado;

import java.util.ArrayList;
public class TabelaHash_EncadeamentoSeparado {

    private final int capacidade;
    private ArrayList<EntradaChaveValor> [] tabela;

    public TabelaHash_EncadeamentoSeparado(int capacidade) {
        this.capacidade = capacidade;
        tabela = new ArrayList[capacidade];

        for(int i = 0; i < capacidade; i++){
            tabela[i] = new ArrayList<>();
        }
    }

    private int funcaoHash(int chave){
        return Math.abs(chave) % capacidade;
    }

    public void adcionar(int chave, String valor){
        int indice = funcaoHash(chave);
        ArrayList<EntradaChaveValor> lista = tabela[indice];
        for(int i = 0; i <= capacidade; i++){
            if(lista.get(i).getChave() == chave){
                lista.get(i).setValor(valor);
            }
        }
    }

    public String buscar(int chave){
        int indice = funcaoHash(chave);
        ArrayList<EntradaChaveValor> lista = tabela[indice];
        for(int i = 0; i <= capacidade; i++){
            if(lista.get(i).getChave() == chave){
                return lista.get(i).getValor();
            }
        }
        return null;
    }

    public void remover(int chave){
        int indice = funcaoHash(chave);
        ArrayList<EntradaChaveValor> lista = tabela[indice];
        EntradaChaveValor removerentrada = null;
        for(int i = 0; i <= capacidade; i++){
            if(lista.get(i).getChave() == chave){
                removerentrada = lista.get(i);
                break;
            }
        }
        if(removerentrada != null){
            tabela[indice].remove(removerentrada);
        }
    }

    public void exibirTabela(){
        for(int i = 0; i < capacidade; i++){
            System.out.println("Índice " + i + ": ");
            ArrayList<EntradaChaveValor> lista = tabela[i];
            if(lista.isEmpty()){
                System.out.println("[]");
            }
            else{
                for(int j = 0; j <= lista.size(); j++){
                    System.out.println(lista.get(j).toString());
                }
            }
        }
    }


}
