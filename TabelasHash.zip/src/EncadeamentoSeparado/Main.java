package EncadeamentoSeparado;

public class Main {
    public static void main(String[] args) {

        TabelaHash_EncadeamentoSeparado thes = new TabelaHash_EncadeamentoSeparado(10);
        thes.adcionar(15, "chave 1");
        thes.adcionar(72, "chave 2");
        thes.adcionar(22, "chave 3");
        thes.adcionar(45, "chave 4");
        thes.adcionar(47, "chave 5");
        thes.exibirTabela();
        thes.remover(72);
        thes.exibirTabela();
        thes.buscar(47);


    }
}
