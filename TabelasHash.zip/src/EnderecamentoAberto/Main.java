package EnderecamentoAberto;

public class Main {
    public static void main(String[] args) {

        TabelaHash_EnderecamentoAberto tbea = new TabelaHash_EnderecamentoAberto(10);
        tbea.adcionar(141, "chave 1");
        tbea.adcionar(53, "chave 2");
        tbea.adcionar(2, "chave 3");
        tbea.adcionar(48, "chave 4");
        tbea.adcionar(97, "chave 5");
        tbea.exibirTabela();
        tbea.remover(2);
        tbea.exibirTabela();
        tbea.buscar(48);
    }
}

