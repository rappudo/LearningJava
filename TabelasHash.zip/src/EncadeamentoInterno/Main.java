package EncadeamentoInterno;

public class Main {
    public static void main(String[] args) {

        TabelaHash_EncadeamentoInterno thei = new TabelaHash_EncadeamentoInterno(10,5);
        thei.adcionar(62, "chave 1");
        thei.adcionar(99, "chave 2");
        thei.adcionar(9, "chave 3");
        thei.adcionar(31, "chave 4");
        thei.adcionar(47, "chave 5");
        thei.adcionar(77, "chave 6");
        thei.adcionar(26, "chave 7");
        thei.adcionar(51, "chave 8");
        thei.adcionar(7, "chave 9");
        thei.adcionar(29, "chave 10");
        thei.exibir();
        thei.remover(9);
        thei.exibir();
        thei.buscar(7);



    }
}
