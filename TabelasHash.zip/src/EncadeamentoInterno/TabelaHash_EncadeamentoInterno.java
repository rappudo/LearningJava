package EncadeamentoInterno;

import EncadeamentoSeparado.EntradaChaveValor;
import EncadeamentoSeparado.TabelaHash_EncadeamentoSeparado;

public class TabelaHash_EncadeamentoInterno {

    private final int p, s;
    private EntradaChaveValor[] tabela;
    private boolean[] usado;
    private int indiceColisoes;

    public TabelaHash_EncadeamentoInterno(int p, int s){
        this.p = p;
        this.s = s;
        this.tabela = new EntradaChaveValor[p + s];
        this.usado = new boolean[s];
        this.indiceColisoes = p;
    }

    private int funcaoHash(int chave){
        return Math.abs(chave) % p;
    }

    public void adcionar(int chave, String valor){
        int indice = funcaoHash(chave);
        if(tabela[indice] == null | tabela[indice].getChave() == chave){
            tabela[indice] = new EntradaChaveValor(chave, valor);
        }
        else{
            boolean inserido = false;
            for(int i = p; i <= p + s; i++){
                if(usado[i - p] == false){
                    tabela[i] = new EntradaChaveValor(chave, valor);
                    usado[i - p] = true;
                    inserido = true;
                    break;
                }
            }
            if(inserido == false){
                System.out.println("Erro: Tabela de colisões cheia");
            }
        }
    }

    public String buscar(int chave){
        int indice = funcaoHash(chave);
        if(tabela[indice] != null && tabela[indice].getChave() == chave){
            return tabela[indice].getValor();
        }
        for(int i = p; i <= p + s; i++){
            if(tabela[i] != null && tabela[i].getChave() == chave){
                return tabela[i].getValor();
            }
        }
        return null;
    }

    public boolean remover(int chave){
        int indice = funcaoHash(chave);
        if(tabela[indice] != null && tabela[indice].getChave() == chave){
            tabela[indice] = null;
            return true;
        }
        for(int i = p; i <= p + s; i++){
            if(tabela[i] != null && tabela[i].getChave() == chave){
                tabela[i] = null;
                usado[i-p] = false;
                return true;
            }
        }
        return false;
    }

    public void exibir(){
        System.out.println("Tabela p:");
        for(int i = 0; i <= p; i++){
            if(tabela[i] != null){
                System.out.println("Índice " + i + ": " + tabela[i]);
            }
            else{
                System.out.println("Índice " + i + ": vazio");
            }
        }
        System.out.println("\nTabela S (Colisões): ");
        for(int i =p; i <= p + s; i++){
            if(tabela[i] != null){
                System.out.println("Índice " + i + ": " + tabela[i]);
            }
            else{
                System.out.println("Índice " + i + ": vazio");
            }
        }
    }

}
