package EncadeamentoInterno;

public class EntradaChaveValor {

    private int chave;
    private String Valor;

    public EntradaChaveValor(int chave, String Valor) {
        this.chave = chave;
        this.Valor = Valor;
    }

    public String getValor() {
        return Valor;
    }

    public void setValor(String valor) {
        Valor = valor;
    }

    public int getChave() {
        return chave;
    }

    @Override
    public String toString() {
        return "{" + chave + " = " + Valor + '}';
    }
}
