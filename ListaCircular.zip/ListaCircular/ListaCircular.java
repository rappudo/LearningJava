package Ex1_2210;

public class ListaCircular {

    private No inicio, fim;
    private int tamanho;

    public ListaCircular() {
        inicio = fim = null;
        tamanho = 0;
    }

    public boolean isEmpty() {
        return (inicio == null && fim == null);
    }

    public void inserirNaFrente(int dado) {
        No novoNo = new No(dado);
        if (isEmpty()) {
            inicio = fim = novoNo;
            fim.setProxNo(inicio);
            tamanho++;
        } else {
            novoNo.setProxNo(inicio);
            inicio = novoNo;
            fim.setProxNo(inicio);
            tamanho++;
        }
    }

    public void inserirNoFundo(int dado) {
        No novoNo = new No(dado);
        if (isEmpty()) {
            inicio = fim = novoNo;
            fim.setProxNo(inicio);
            tamanho++;
        } else {
            fim.setProxNo(novoNo);
            fim = novoNo;
            fim.setProxNo(inicio);
            tamanho++;
        }
    }

    public void inserir(int dado, int pos) {
        No novoNo = new No(dado);
        if (pos > tamanho) {
            inserirNoFundo(dado);
        } else {
            No aux = inicio;
            No aux2 = inicio;
            for (int i = 0; i <= pos; i++) {
                if (i != pos) {
                    aux2 = aux;
                    aux = aux.getProxNo();
                }
            }
            aux2.setProxNo(novoNo);
            novoNo.setProxNo(aux);
            tamanho++;
        }
    }

    public int removerDaFrente() {
        No aux = inicio;
        fim.setProxNo(inicio.getProxNo());
        tamanho--;
        return aux.getDado();
    }

    public int removerDoFundo() {
        No temp = fim;
        No aux = inicio;
        while (aux.getProxNo() != inicio) {
            aux = aux.getProxNo();
        }
        aux.setProxNo(inicio);
        fim = aux;
        tamanho--;
        return temp.getDado();
    }

    public int removerPorPos(int pos) {
        if(pos > tamanho){
            return -1;
        }
        else {
            No aux = inicio;
            No aux2 = inicio;
            for (int i = 0; i <= pos; i++) {
                if (i != pos) {
                    aux2 = aux;
                    aux = aux.getProxNo();
                }
            }
            aux2.setProxNo(aux.getProxNo());
            tamanho--;
            return aux.getDado();
        }
    }

    public int removerPorDado(int dado){
        No aux = inicio;
        No aux2 = inicio;
        for(int i = 0; i <= tamanho; i++){
            if(aux.getDado() == dado){
                aux2.setProxNo(aux.getProxNo());
                tamanho--;
                return aux.getDado();
            }
            aux2 = aux;
            aux = aux.getProxNo();
        }
        return -1;
    }

    public boolean buscarPorDado(int dado){
        No aux = inicio;
        for(int i = 0; i <= tamanho; i++){
            if(aux.getDado() == dado){
                return true;
            }
            aux = aux.getProxNo();
        }
        return false;
    }

    public int bucarPorPos(int pos){
        No aux = inicio;
        for(int i = 0; i <= pos; i++){
            aux = aux.getProxNo();
        }
        return aux.getDado();
    }

    public String listar(){
        String texto = "Lista: ";
        No aux = inicio;
        for(int i = 0; i <= tamanho; i++){
            texto += "\nÍndice [" + i + "], Dado: " + aux.getDado() + ". ";
            aux = aux.getProxNo();
        }
        return texto;
    }
}